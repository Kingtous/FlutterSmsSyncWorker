if(!me) cancel("Please Login First",401);

//hide("phoneNumber");
hide("id");
var queryPhone = me.username;


// var response = this;

// dpd.sms.get({ phoneNumber : queryPhone},function (result, err) {
//   if(err) return console.log(err);
//   response = result;
// });


// dpd.sms.get({ phoneNumber : queryPhone,$limitRecursion: 1},function (result, err) {
//   if(err) return console.log(err);
//   this.result = result;
// });